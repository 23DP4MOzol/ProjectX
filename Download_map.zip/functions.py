# Funkcija, lai pievienotu treniņu

# Saglabāt treniņu datus

# Funkcija, lai skatītos iepriekšējos treniņus

# Funkcija, lai rediģētu treniņu

# Funkcija, lai dzēstu treniņu

# Funkcija, lai parādītu statistiku par treniņiem

# Funkcija, lai veiktu treniņu vēstures meklēšanu