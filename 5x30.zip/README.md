# 5x30 - Fitness Training Tracker

**5x30** ir programma, kas palīdz lietotājiem sekot līdzi treniņu progresam, saglabāt datus par vingrinājumiem un sniedz ieteikumus nākamajiem treniņiem, pamatojoties uz veiktajiem rezultātiem.

Ar **5x30** lietotāji var:
- Pievienot, rediģēt un dzēst treniņu datus
- Sekot līdzi svara un atkārtojumu izmaiņām
- Iegūt statistiku par kopējo treniņu skaitu un svaru
- Saņemt ieteikumus nākamajam treniņam

## Satura rādītājs

- [Prasības](#prasības)
- [Instalācija](#instalācija)
- [Kā lietot](#kā-lietot)
- [Error Handling](#error-handling)

## Prasības

- **Python 3.x**
- **tkinter** (instalēts kopā ar Python)
- **matplotlib** (ja vēlies izmantot grafikus nākotnē)

## Instalācija

1. Klonē vai lejupielādē šo repozitoriju.
2. Pārliecinies, ka tev ir instalēts **Python 3.x**.
3. Lai sāktu lietot, nav nepieciešama papildu instalācija, jo visas nepieciešamās bibliotēkas (kā `tkinter`) jau ir iekļautas Python standarta bibliotēkās.

---

## Kā lietot

**5x30** programma piedāvā vienkāršu un intuitīvu grafisko lietotāja interfeisu, izmantojot **tkinter**. Lietotājs var:
- Pievienot jaunu treniņu.
- Rediģēt esošos treniņus.
- Dzēst nevajadzīgos treniņus.
- Skatīt statistiku par progresu, piemēram, kopējo treniņu skaitu un vidējo svaru.
- Saņemt personalizētus ieteikumus par to, kā uzlabot nākamo treniņu.

---

## Error Handling

- Ja treniņu dati tiek saglabāti vai ielādēti nepareizi, programma parādīs kļūdas ziņojumu.
- Ja mēģina rediģēt vai dzēst neeksistējo treniņu (nav atrasts ar doto ID), programma sniegs informāciju par kļūdu.
- Ja nav pieejami dati par treniņiem, programma informēs lietotāju, ka treniņu nav.

---

## Secinājumi

**5x30** ir lielisks rīks treniņu sekotājiem, kas vēlas uzlabot savu veiktspēju un izsekot progresam. Programma nodrošina ērtu veidu, kā pievienot, rediģēt un analizēt treniņus, kā arī sniedz ieteikumus, lai palīdzētu sasniegt vēl labākus rezultātus.
